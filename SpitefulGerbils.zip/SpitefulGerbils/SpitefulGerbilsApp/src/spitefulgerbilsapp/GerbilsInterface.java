package spitefulgerbilsapp;

/**
 *
 * @author jones
 */
public interface GerbilsInterface 
{
    public void setCharInfo();
    public void accessCharInfo();
    
    
    public void setNewChar();
    public void getNewChar();
    
    public void setUserAccount();
    public void getUserAccount();
}
