package spitefulgerbilsapp;

/**
 *
 * @author XWP921
 */
public class SpitefulGerbilsApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {

            DiceRoller dice = new DiceRoller();

    
    
            //dice.roll3d6Dice(3,6);
            //dice.roll3d6Dice(3,6);
            //dice.roll5d6Dice(5,6);
            //dice.rollExtra5d6Dice(5,6);
            //dice.chooseDice();
                    
            HeightWeight test = new HeightWeight();
            //yuh.run();
            //test.generateRaceScore();
            
            
        //TitleScreen test1 = new TitleScreen(); //Jacobs shit
        
        //test1.menuSelection();
        //test1.createAccount();

    
}
}